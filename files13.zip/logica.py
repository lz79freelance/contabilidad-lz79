"""
logica.py
---------
Lógica de negocio: parseo de QR, asistente por palabras clave,
generación de los HTML de factura/albarán/informe, y verificación de
la cadena de hashes de `movimientos`.

Cambios respecto al original:
- `generar_html_documento_individual` y `generar_html_gestoria` ahora
  escapan con `html.escape()` todo texto que viene de datos del
  usuario (concepto, cliente_info) antes de insertarlo en el HTML. En
  el original iban directos por f-string: si alguna vez un cliente o
  concepto contuviera algo como `<script>`, el HTML generado lo
  ejecutaría al abrirlo. El riesgo es bajo porque el archivo es local,
  pero es una corrección barata.
- Se usa `almacenamiento.get_ruta_plantillas()` en vez de una carpeta
  "templates" fija, y `abrir_archivo_si_escritorio` en vez de
  `webbrowser.open` directo (ver ese módulo).
- Nueva función `verificar_cadena_movimientos()`: el main.py original
  guardaba `hash_anterior`/`hash_actual` encadenados (una especie de
  libro contable inmutable) pero nunca los comprobaba. Esta función
  recorre la cadena y dice si sigue íntegra o en qué punto se rompió.
"""

import html
import os
from datetime import datetime

from almacenamiento import get_ruta_plantillas, abrir_archivo_si_escritorio
from db import (
    cargar_totales_db,
    obtener_inventario_db,
    buscar_en_inventario,
    contar_facturas_emitidas,
    contar_movimientos_por_tipo,
    contar_contactos,
    obtener_top_clientes,
    obtener_trimestre_actual,
    obtener_movimientos_para_cadena,
    obtener_movimientos_periodo,
)

# ---------------------------------------------------------------------
# QR / lectura de códigos
# ---------------------------------------------------------------------


def procesar_texto_factura_qr(texto_qr: str):
    """Extrae un importe numérico (si lo hay) del contenido de un QR/
    código de barras. Idéntico al original: no se tocó la lógica."""
    partes = [p.strip() for p in texto_qr.replace(";", "|").split("|")]
    importe_encontrado = 0.0
    concepto_encontrado = texto_qr

    for parte in partes:
        try:
            limpio = parte.replace("€", "").replace(",", ".").strip()
            val = float(limpio)
            if val > 0:
                importe_encontrado = val
        except ValueError:
            pass

    return concepto_encontrado, importe_encontrado


# ---------------------------------------------------------------------
# Asistente por palabras clave
# ---------------------------------------------------------------------

def procesar_consulta_asistente(consulta_usuario: str) -> str:
    texto = consulta_usuario.lower().strip()

    if any(k in texto for k in ["hola", "buenas", "buenos dias", "buenas tardes", "hey"]):
        return "👋 ¡Hola! Pregúntame por **balance**, **stock**, **alertas**, **facturas**, **albaranes**, **compras**, **contactos**, **trimestre** o el **mejor cliente**."

    if any(k in texto for k in ["gracias", "genial", "perfecto"]):
        return "🙌 ¡De nada! Aquí me tienes para lo que necesites."

    if any(k in texto for k in ["balance", "iva", "beneficio", "ganancia", "cuanto gane", "303", "130"]):
        ing, gas = cargar_totales_db()
        dif = ing - gas
        iva_rep = ing - (ing / 1.21)
        iva_sop = gas - (gas / 1.21)
        return (f"📊 **Resumen Financiero:**\n\n"
                f"• **Ingresos Totales:** +{ing:.2f} €\n"
                f"• **Gastos / Compras:** -{gas:.2f} €\n"
                f"• **Rendimiento Neto:** {dif:.2f} €\n\n"
                f"• **IVA Repercutido:** {iva_rep:.2f} €\n"
                f"• **IVA Soportado:** {iva_sop:.2f} €\n"
                f"• **Liquidación Estimada (Modelo 303):** {(iva_rep - iva_sop):.2f} €")

    if any(k in texto for k in ["alerta", "minimo", "reponer", "falta"]):
        items = obtener_inventario_db()
        criticos = [f"• {desc} (Stock: {stock} | Mínimo: {minimo})" for sku,
                    desc, cat, stock, minimo, costo in items if stock < minimo]
        if criticos:
            return "⚠️ **Artículos en stock crítico:**\n" + "\n".join(criticos)
        return "✅ Todo el stock se encuentra por encima del umbral mínimo."

    if any(k in texto for k in ["stock", "inventario", "buscar", "precio"]):
        palabras = [w for w in texto.split() if w not in [
            "stock", "de", "el", "la", "buscar", "precio", "cuanto", "hay"]]
        if not palabras:
            total_items = len(obtener_inventario_db())
            return f"📦 Actualmente tienes {total_items} referencias registradas en inventario."

        busqueda = " ".join(palabras)
        resultados = buscar_en_inventario(busqueda)

        if resultados:
            lineas = [f"• **{sku}** - {desc}: {stock} uds a {costo:.2f} €" for sku,
                      desc, stock, costo in resultados]
            return "📦 **Resultados de Inventario:**\n" + "\n".join(lineas)
        return f"❌ No se encontraron productos que coincidan con '{busqueda}'."

    if any(k in texto for k in ["factura", "ventas", "total facturado"]):
        total_num, total_imp = contar_facturas_emitidas()
        return f"🧾 Has emitido un total de **{total_num} facturas** por un valor acumulado de **{total_imp:.2f} €**."

    if "albaran" in texto or "albarán" in texto:
        total_num, total_imp = contar_movimientos_por_tipo("Albaranes")
        return f"📦 Llevas **{total_num} albaranes** registrados por un total de **{total_imp:.2f} €**."

    if any(k in texto for k in ["compra", "gasto", "cuanto he gastado"]):
        total_num, total_imp = contar_movimientos_por_tipo("Compras")
        return f"🧮 Tienes **{total_num} compras/gastos** registrados por un total de **{total_imp:.2f} €**."

    # OJO: este bloque va ANTES que el de "cliente"/"contacto" a secas,
    # porque "mejor cliente" contiene la palabra "cliente" y, si el
    # orden fuera al revés, el bloque de contactos la interceptaría
    # primero y el ranking nunca se alcanzaría.
    if any(k in texto for k in ["mejor cliente", "top cliente", "cliente que mas", "cliente que más", "ranking"]):
        top = obtener_top_clientes(5)
        if not top:
            return "📊 Todavía no hay facturas asociadas a ningún cliente."
        lineas = [f"{i+1}. **{cli}** — {total:.2f} €" for i,
                  (cli, total) in enumerate(top)]
        return "🏆 **Clientes por facturación acumulada:**\n" + "\n".join(lineas)

    if any(k in texto for k in ["cliente", "proveedor", "contacto", "directorio"]):
        num_clientes, num_proveedores = contar_contactos()
        return (f"👥 **Directorio de contactos:**\n\n"
                f"• Clientes: **{num_clientes}**\n"
                f"• Proveedores: **{num_proveedores}**")

    if "trimestre" in texto:
        trimestre = obtener_trimestre_actual()
        return f"📅 Estás en el **{trimestre}º trimestre** del año. Recuerda que el informe para tu gestoría lo generas desde el módulo de Historial."

    return ("🤖 Comandos y consultas disponibles:\n\n"
            "• *'Balance'* o *'IVA'* $\\rightarrow$ Consulta liquidación trimestral estimada.\n"
            "• *'Stock [nombre]'* $\\rightarrow$ Consulta existencias y precios.\n"
            "• *'Alertas'* $\\rightarrow$ Ver productos bajo stock mínimo.\n"
            "• *'Facturas'* $\\rightarrow$ Conteo y total facturado acumulado.\n"
            "• *'Albaranes'* $\\rightarrow$ Conteo y total de albaranes.\n"
            "• *'Compras'* o *'Gastos'* $\\rightarrow$ Conteo y total gastado.\n"
            "• *'Contactos'* $\\rightarrow$ Nº de clientes y proveedores.\n"
            "• *'Trimestre'* $\\rightarrow$ En qué trimestre fiscal estás.\n"
            "• *'Mejor cliente'* $\\rightarrow$ Ranking de clientes por facturación.")


# ---------------------------------------------------------------------
# Verificación de la cadena de hashes
# ---------------------------------------------------------------------

def verificar_cadena_movimientos():
    """Recorre `movimientos` en orden y recalcula cada hash a partir del
    anterior, tal y como se generó en `db.guardar_movimiento_db`.
    Devuelve (integra: bool, mensaje: str, num_doc_rotura: str | None).

    Esto es lo que le faltaba a la cadena de hashes del original: se
    guardaba hash_anterior/hash_actual pero nada los comprobaba nunca.
    """
    import hashlib

    filas = obtener_movimientos_para_cadena()
    if not filas:
        return True, "No hay movimientos registrados todavía.", None

    hash_esperado = "PRIMER_REGISTRO_LZ79"
    for _id, num_doc, fecha_hora, importe, hash_anterior, hash_actual in filas:
        if hash_anterior != hash_esperado:
            return False, f"Rotura de la cadena en el documento {num_doc}: el hash_anterior no coincide.", num_doc

        cadena = f"{num_doc}|{fecha_hora}|{importe:.2f}|{hash_anterior}"
        recalculado = hashlib.sha256(cadena.encode("utf-8")).hexdigest()
        if recalculado != hash_actual:
            return False, f"Rotura de la cadena en el documento {num_doc}: el hash_actual no coincide con lo registrado (¿se editó el registro directamente en la BD?).", num_doc

        hash_esperado = hash_actual

    return True, f"Cadena íntegra: {len(filas)} movimientos verificados sin roturas.", None


# ---------------------------------------------------------------------
# Generación de documentos HTML
# ---------------------------------------------------------------------

def generar_html_documento_individual(num_doc, tipo, concepto, base, cuota_iva, tipo_iva=21.0,
                                       cuota_irpf=0.0, tipo_irpf=0.0, cuota_recargo=0.0,
                                       total=None, cliente_info="", fecha_hora=""):
    if total is None:
        total = base + cuota_iva + cuota_recargo - cuota_irpf

    # Escapado de todo lo que viene de datos introducidos por el usuario.
    concepto = html.escape(str(concepto))
    cliente_info = html.escape(str(cliente_info))
    num_doc_html = html.escape(str(num_doc))

    es_venta = "Facturas" in tipo or "Ventas" in tipo
    color_tipo = "green" if es_venta else "red"

    filas_impuestos = f"<tr><td><strong>IVA ({tipo_iva:.0f}%):</strong></td><td class='num'>+{cuota_iva:.2f} €</td></tr>"
    if cuota_recargo > 0:
        filas_impuestos += f"<tr><td><strong>Recargo Equivalencia:</strong></td><td class='num'>+{cuota_recargo:.2f} €</td></tr>"
    if cuota_irpf > 0:
        filas_impuestos += f"<tr><td><strong>Retención IRPF ({tipo_irpf:.0f}%):</strong></td><td class='num'>-{cuota_irpf:.2f} €</td></tr>"

    plantilla = f"""<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>Documento {num_doc_html}</title>
<style>
    body {{ font-family: Arial, sans-serif; margin: 40px; color: #222; }}
    .header {{ border-bottom: 2px solid #444; padding-bottom: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; }}
    .empresa {{ font-size: 20px; font-weight: bold; color: #0F172A; }}
    .titulo {{ text-align: right; font-size: 22px; font-weight: bold; color: {color_tipo}; }}
    .datos-cliente {{ margin-top: 20px; font-size: 14px; border: 1px solid #ddd; padding: 12px; border-radius: 6px; background: #F8FAFC; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 25px; font-size: 13px; }}
    th, td {{ border: 1px solid #ccc; padding: 8px; text-align: left; }}
    th {{ background-color: #1E293B; color: white; }}
    .num {{ text-align: right; }}
    .totales {{ margin-top: 20px; width: 50%; margin-left: auto; font-size: 14px; }}
    .totales td {{ padding: 6px; }}
    .qr-section {{ margin-top: 30px; text-align: right; }}
    .footer {{ margin-top: 40px; font-size: 11px; color: #666; text-align: center; }}
</style></head>
<body>
    <div class="header">
        <div>
            <div class="empresa">LZ79 ESSENTIAL</div>
            <div style="font-size: 12px; color: #64748B;">Software de Gestión y Contabilidad</div>
        </div>
        <div class="titulo">
            {html.escape(tipo.upper())}<br>
            <span style="font-size: 16px; color: #333;">Nº {num_doc_html}</span><br>
            <span style="font-size: 12px; color: #666;">Fecha: {html.escape(str(fecha_hora))}</span>
        </div>
    </div>
    <div class="datos-cliente">
        <strong>Asignado a:</strong> {cliente_info}<br>
        <strong>Concepto:</strong> {concepto}
    </div>
    <table>
        <thead>
            <tr>
                <th>Concepto / Descripción</th>
                <th class="num">Base Imponible</th>
                <th class="num">IVA ({tipo_iva:.0f}%)</th>
                <th class="num">Total Operación</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{concepto}</td>
                <td class="num">{base:.2f} €</td>
                <td class="num">{cuota_iva:.2f} €</td>
                <td class="num">{(base + cuota_iva):.2f} €</td>
            </tr>
        </tbody>
    </table>
    <table class="totales">
        <tr><td><strong>Base Imponible Total:</strong></td><td class="num">{base:.2f} €</td></tr>
        {filas_impuestos}
        <tr><td style="font-size: 15px;"><strong>TOTAL:</strong></td><td class="num" style="font-size: 15px;"><strong>{total:.2f} €</strong></td></tr>
    </table>
    <div class="qr-section">
        <p style="font-size: 11px; color: #555;">Verifique este documento en la Sede Electrónica de la AEAT</p>
        <div style="display: inline-block; width: 90px; height: 90px; border: 1px dashed #94A3B8; text-align: center; line-height: 90px; font-size: 10px; color: #64748B; background: #F1F5F9;">QR Veri*factu</div>
    </div>
    <div class="footer">
        LZ79 Essential · Generado automáticamente por el sistema de gestión.
    </div>
</body>
</html>"""

    ruta_plantillas = get_ruta_plantillas()
    nombre_archivo = os.path.join(
        ruta_plantillas, f"Doc_{str(num_doc).replace('/', '_')}.html")
    with open(nombre_archivo, "w", encoding="utf-8") as f:
        f.write(plantilla)

    abrir_archivo_si_escritorio(os.path.abspath(nombre_archivo))
    return nombre_archivo


def generar_html_gestoria(anio, trimestre):
    movimientos = obtener_movimientos_periodo()

    facturas = [m for m in movimientos if "Facturas" in m[5]]
    albaranes = [m for m in movimientos if "Albaranes" in m[5]]
    compras = [m for m in movimientos if "Compras" in m[5]]

    def construir_seccion_tabla(titulo_seccion, lista_movs, color_tag):
        filas_html = ""
        t_base, t_iva, t_neto = 0.0, 0.0, 0.0
        for num_f, fecha, cliente, concepto, importe, tipo in lista_movs:
            base = importe / 1.21
            iva = importe - base
            t_base += base
            t_iva += iva
            t_neto += importe
            num_f_s = html.escape(str(num_f))
            cliente_s = html.escape(str(cliente))
            concepto_s = html.escape(str(concepto))
            tipo_s = html.escape(str(tipo))
            tag = f"<span style='color:{color_tag}; font-weight:bold;'>[{tipo_s}]</span>"
            filas_html += f"<tr><td>{num_f_s}</td><td>{tag}</td><td>{fecha}</td><td>{cliente_s}</td><td>{concepto_s}</td><td class='num'>{base:.2f} €</td><td class='num'>{iva:.2f} €</td><td class='num'>{importe:.2f} €</td></tr>"

        if not filas_html:
            filas_html = "<tr><td colspan='8' style='text-align:center;'>Sin registros en esta categoría.</td></tr>"

        return f"""
            <h3>{titulo_seccion}</h3>
            <table>
                <thead>
                    <tr>
                        <th>Nº Doc</th>
                        <th>Tipo</th>
                        <th>Fecha</th>
                        <th>Cliente / Proveedor</th>
                        <th>Concepto</th>
                        <th>Base Imponible</th>
                        <th>IVA</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>{filas_html}</tbody>
            </table>
            <div class="resumen-parcial">
                <p><strong>Base ({titulo_seccion}):</strong> {t_base:.2f} € | <strong>IVA:</strong> {t_iva:.2f} € | <strong>Total:</strong> {t_neto:.2f} €</p>
            </div>
        """, t_base, t_iva, t_neto

    html_facturas, b_fac, iva_fac, t_fac = construir_seccion_tabla(
        "FACTURAS DE VENTA", facturas, "green")
    html_albaranes, b_alb, iva_alb, t_alb = construir_seccion_tabla(
        "ALBARANES", albaranes, "blue")
    html_compras, b_com, iva_com, t_com = construir_seccion_tabla(
        "COMPRAS Y GASTOS", compras, "red")

    resultado_iva = iva_fac - iva_com

    titulo = f"Informe Fiscal para Gestoría - {trimestre}º Trimestre {anio}"
    plantilla = f"""<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>{titulo}</title>
<style>
    body {{ font-family: Arial, sans-serif; margin: 30px; color: #333; }}
    h2 {{ color: #0F172A; border-bottom: 2px solid #38BDF8; padding-bottom: 8px; }}
    h3 {{ color: #1E293B; margin-top: 25px; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }}
    th, td {{ border: 1px solid #ddd; padding: 8px; }}
    th {{ background: #1E293B; color: white; text-align: left; }}
    .num {{ text-align: right; }}
    .resumen-parcial {{ font-size: 12px; background: #F1F5F9; padding: 8px; margin-top: 5px; border-radius: 4px; }}
    .resumen-global {{ background: #F8FAFC; border: 2px solid #CBD5E1; padding: 15px; margin-top: 30px; border-radius: 8px; }}
    .kpi {{ font-size: 16px; font-weight: bold; color: {'#16A34A' if resultado_iva >= 0 else '#DC2626'}; }}
</style></head>
<body>
    <h2>{titulo}</h2>
    <p><strong>Fecha de Generación:</strong> {datetime.now().strftime("%d/%m/%Y %H:%M")}</p>
    {html_facturas}
    {html_albaranes}
    {html_compras}
    <div class="resumen-global">
        <h3>LIQUIDACIÓN FISCAL ESTIMADA (Modelo 303 / 130):</h3>
        <p><strong>Total Facturado (Ventas):</strong> {b_fac:.2f} € (IVA Repercutido: +{iva_fac:.2f} €)</p>
        <p><strong>Total Compras y Gastos:</strong> {b_com:.2f} € (IVA Soportado: -{iva_com:.2f} €)</p>
        <hr/>
        <p class="kpi">Resultado Estimado IVA (Modelo 303): {resultado_iva:.2f} €</p>
        <p><strong>Rendimiento Neto Previo IRPF:</strong> {(b_fac - b_com):.2f} €</p>
    </div>
</body>
</html>"""

    ruta_plantillas = get_ruta_plantillas()
    nombre_archivo = os.path.join(
        ruta_plantillas, f"Informe_Gestoria_{anio}_T{trimestre}.html")
    with open(nombre_archivo, "w", encoding="utf-8") as f:
        f.write(plantilla)

    abrir_archivo_si_escritorio(os.path.abspath(nombre_archivo))
    return nombre_archivo
