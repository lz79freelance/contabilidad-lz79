"""
db.py
-----
Toda la capa de acceso a SQLite: esquema, contactos, inventario,
movimientos y balance.

Cambios respecto al main.py original:
- Conexión centralizada con un context manager (`_conexion()`), en vez
  de repetir `sqlite3.connect(DB_NAME)` / `conn.close()` en cada función.
- Numeración de documentos (F-2026-0001, A-2026-0001, C-2026-0001)
  movida de un `COUNT(*)` a una tabla `contadores` dedicada. Con
  COUNT(*), si alguna vez se borra un movimiento, el siguiente número
  generado puede repetirse; con una tabla de contadores que solo
  incrementa, el número es siempre único aunque borres registros.
"""

import os
import sqlite3
import hashlib
from contextlib import contextmanager
from datetime import datetime

from almacenamiento import get_ruta_datos

DB_NAME = os.path.join(get_ruta_datos(), "contabilidad.db")


@contextmanager
def _conexion():
    conn = sqlite3.connect(DB_NAME)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def inicializar_bd():
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS movimientos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo TEXT,
                concepto TEXT,
                importe REAL,
                fecha_hora TEXT,
                num_factura TEXT,
                cliente_info TEXT,
                hash_anterior TEXT,
                hash_actual TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT UNIQUE,
                cif TEXT,
                direccion TEXT,
                es_proveedor INTEGER DEFAULT 0
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventario (
                sku TEXT PRIMARY KEY,
                descripcion TEXT,
                categoria TEXT,
                stock_actual INTEGER,
                nivel_minimo INTEGER,
                costo_unitario REAL
            )
        """)
        # Tabla de contadores: una fila por (serie, año), incrementa sola.
        # Sustituye al COUNT(*) del main.py original para que borrar un
        # movimiento nunca haga que se repita un número de documento.
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS contadores (
                serie TEXT,
                anio INTEGER,
                ultimo INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (serie, anio)
            )
        """)


# ---------------------------------------------------------------------
# Contactos (clientes / proveedores)
# ---------------------------------------------------------------------

def guardar_contacto_db(nombre, cif, direccion, es_proveedor=0):
    try:
        with _conexion() as conn:
            conn.execute(
                "INSERT INTO clientes (nombre, cif, direccion, es_proveedor) VALUES (?, ?, ?, ?)",
                (nombre, cif, direccion, es_proveedor)
            )
        return True
    except sqlite3.IntegrityError:
        return False


def obtener_contactos_db(es_proveedor=None):
    with _conexion() as conn:
        cursor = conn.cursor()
        if es_proveedor is None:
            cursor.execute(
                "SELECT id, nombre, cif, direccion, es_proveedor FROM clientes ORDER BY nombre ASC")
        else:
            cursor.execute(
                "SELECT id, nombre, cif, direccion, es_proveedor FROM clientes WHERE es_proveedor = ? ORDER BY nombre ASC",
                (es_proveedor,)
            )
        return cursor.fetchall()


def eliminar_contacto_db(id_contacto):
    with _conexion() as conn:
        conn.execute("DELETE FROM clientes WHERE id = ?", (id_contacto,))


# ---------------------------------------------------------------------
# Inventario
# ---------------------------------------------------------------------

def obtener_inventario_db():
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT sku, descripcion, categoria, stock_actual, nivel_minimo, costo_unitario FROM inventario ORDER BY sku ASC")
        return cursor.fetchall()


def guardar_producto_inventario_db(sku, descripcion, categoria, stock, minimo, costo):
    try:
        with _conexion() as conn:
            conn.execute("""
                INSERT INTO inventario (sku, descripcion, categoria, stock_actual, nivel_minimo, costo_unitario)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(sku) DO UPDATE SET
                    descripcion=excluded.descripcion,
                    categoria=excluded.categoria,
                    stock_actual=excluded.stock_actual,
                    nivel_minimo=excluded.nivel_minimo,
                    costo_unitario=excluded.costo_unitario
            """, (sku, descripcion, categoria, stock, minimo, costo))
        return True
    except Exception:
        return False


def eliminar_producto_inventario_db(sku):
    with _conexion() as conn:
        conn.execute("DELETE FROM inventario WHERE sku = ?", (sku,))


def vaciar_inventario_db():
    with _conexion() as conn:
        conn.execute("DELETE FROM inventario")


# ---------------------------------------------------------------------
# Movimientos (facturas / albaranes / compras) y contadores
# ---------------------------------------------------------------------

_PREFIJOS_SERIE = {
    "Facturas": "F",
    "Albaranes": "A",
    "Compras": "C",
}


def _siguiente_numero_documento(cursor, tipo: str) -> str:
    """Devuelve el próximo número de documento para la serie de `tipo`,
    incrementando la tabla `contadores` de forma atómica dentro de la
    misma conexión/transacción que la inserción del movimiento."""
    serie = next((s for clave, s in _PREFIJOS_SERIE.items()
                 if clave in tipo), None)
    if serie is None:
        return "DOC_S_N"

    anio = datetime.now().year
    cursor.execute(
        "INSERT INTO contadores (serie, anio, ultimo) VALUES (?, ?, 1) "
        "ON CONFLICT(serie, anio) DO UPDATE SET ultimo = ultimo + 1",
        (serie, anio)
    )
    cursor.execute(
        "SELECT ultimo FROM contadores WHERE serie = ? AND anio = ?", (serie, anio))
    contador = cursor.fetchone()[0]
    return f"{serie}-{anio}-{contador:04d}"


def guardar_movimiento_db(tipo, concepto, importe, cliente_info=""):
    with _conexion() as conn:
        cursor = conn.cursor()
        fecha_hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute(
            "SELECT hash_actual FROM movimientos ORDER BY id DESC LIMIT 1")
        fila = cursor.fetchone()
        hash_anterior = fila[0] if fila else "PRIMER_REGISTRO_LZ79"

        num_doc = _siguiente_numero_documento(cursor, tipo)

        cadena = f"{num_doc}|{fecha_hora}|{importe:.2f}|{hash_anterior}"
        hash_actual = hashlib.sha256(cadena.encode("utf-8")).hexdigest()

        cursor.execute("""
            INSERT INTO movimientos (tipo, concepto, importe, fecha_hora, num_factura, cliente_info, hash_anterior, hash_actual)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (tipo, concepto, importe, fecha_hora, num_doc, cliente_info, hash_anterior, hash_actual))

        return num_doc, fecha_hora


def obtener_todos_movimientos_db():
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, num_factura, tipo, fecha_hora, cliente_info, concepto, importe FROM movimientos ORDER BY id DESC")
        return cursor.fetchall()


def obtener_movimientos_para_cadena():
    """Todos los movimientos en orden de inserción, con sus hashes,
    tal y como los necesita la verificación de integridad."""
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, num_factura, fecha_hora, importe, hash_anterior, hash_actual FROM movimientos ORDER BY id ASC")
        return cursor.fetchall()


def obtener_movimientos_periodo():
    """Movimientos completos (para informes de gestoría), ordenados por id."""
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT num_factura, fecha_hora, cliente_info, concepto, importe, tipo FROM movimientos ORDER BY id ASC")
        return cursor.fetchall()


def buscar_en_inventario(busqueda: str):
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT sku, descripcion, stock_actual, costo_unitario FROM inventario WHERE sku LIKE ? OR descripcion LIKE ?",
            (f"%{busqueda}%", f"%{busqueda}%")
        )
        return cursor.fetchall()


def contar_facturas_emitidas():
    return contar_movimientos_por_tipo("Facturas")


def contar_movimientos_por_tipo(prefijo_tipo: str):
    """Conteo y suma genéricos para cualquier serie (Facturas, Albaranes,
    Compras...). Usado por el asistente para responder sobre cualquier
    tipo de documento sin duplicar la consulta SQL por cada uno."""
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT COUNT(*), SUM(importe) FROM movimientos WHERE tipo LIKE ?",
            (f"{prefijo_tipo}%",)
        )
        total_num, total_imp = cursor.fetchone()
        return total_num or 0, total_imp or 0.0


def contar_contactos():
    """Devuelve (num_clientes, num_proveedores)."""
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT es_proveedor, COUNT(*) FROM clientes GROUP BY es_proveedor")
        filas = dict(cursor.fetchall())
    return filas.get(0, 0), filas.get(1, 0)


def obtener_top_clientes(limite=5):
    """Clientes/proveedores con más importe facturado (excluye 'Compras',
    solo cuenta lo que se les ha facturado a ellos como cliente_info)."""
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT cliente_info, SUM(importe) as total
            FROM movimientos
            WHERE tipo LIKE 'Facturas%' AND cliente_info != ''
            GROUP BY cliente_info
            ORDER BY total DESC
            LIMIT ?
        """, (limite,))
        return cursor.fetchall()


def cargar_totales_db():
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT tipo, SUM(importe) FROM movimientos GROUP BY tipo")
        filas = cursor.fetchall()

    ingresos, gastos = 0.0, 0.0
    for tipo, total in filas:
        if "Facturas" in tipo or "Ventas" in tipo:
            ingresos += total
        elif "Compras" in tipo:
            gastos += total
    return ingresos, gastos


def obtener_producto_por_sku(sku):
    with _conexion() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT sku, descripcion, categoria, stock_actual, nivel_minimo, costo_unitario FROM inventario WHERE sku = ?",
            (sku,)
        )
        return cursor.fetchone()


def obtener_trimestre_actual():
    mes = datetime.now().month
    if mes in (1, 2, 3):
        return "1"
    elif mes in (4, 5, 6):
        return "2"
    elif mes in (7, 8, 9):
        return "3"
    else:
        return "4"
