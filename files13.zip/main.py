"""
main.py
-------
Solo la UI de Flet (vistas y rutas). Toda la lógica de datos vive en
db.py, la lógica de negocio en logica.py, la exportación de
inventario en exportacion.py y el escaneo de QR en escaner.py.

Cambios respecto al original (además de la separación en módulos):
- Se quitó el único `print()` de depuración que quedaba en el
  escáner (ahora en escaner.py, silenciado explícitamente).
- La vista `/almacen/editar/<sku>` usaba una consulta SQL suelta
  dentro de main.py; ahora llama a `db.obtener_producto_por_sku()`.
- La vista `/historial` incorpora un botón "Verificar integridad"
  que llama a `logica.verificar_cadena_movimientos()` — la cadena de
  hashes ya existía en el original, pero nada la comprobaba nunca.
- Los imports de cv2/pyzbar han desaparecido de este archivo: ahora
  solo se importan dentro de `escaner.escanear_qr_escritorio`, así
  que un build para móvil que no incluya OpenCV no rompe al arrancar.
"""

import threading

import flet as ft

from db import (
    inicializar_bd,
    guardar_contacto_db,
    obtener_contactos_db,
    eliminar_contacto_db,
    obtener_inventario_db,
    guardar_producto_inventario_db,
    eliminar_producto_inventario_db,
    obtener_producto_por_sku,
    vaciar_inventario_db,
    guardar_movimiento_db,
    obtener_todos_movimientos_db,
    cargar_totales_db,
    obtener_trimestre_actual,
)
from exportacion import exportar_inventario_excel, importar_inventario_excel
from logica import (
    procesar_texto_factura_qr,
    procesar_consulta_asistente,
    generar_html_documento_individual,
    generar_html_gestoria,
    verificar_cadena_movimientos,
)
from escaner import escanear_qr

COLOR_FONDO = "#0F172A"
COLOR_PANEL = "#1E293B"
COLOR_ACCENTO = "#38BDF8"
COLOR_TEXTO = "#F8FAFC"


def main(page: ft.Page):
    inicializar_bd()

    page.title = "LZ79 Essential - Gestión y Contabilidad"
    page.bgcolor = COLOR_FONDO
    page.theme = ft.Theme(color_scheme_seed="sky")
    page.window_width = 520
    page.window_height = 840

    def crear_vista(route):
        def wrap_responsive(content):
            return ft.Container(
                content=content,
                padding=20,
                alignment=ft.Alignment(0, -1),
                expand=True
            )

        if route == "/":
            tarjetas_menu = [
                ("Facturas", "/facturas", ft.Icons.RECEIPT_LONG_ROUNDED, False),
                ("Inventario", "/almacen", ft.Icons.INVENTORY_2_ROUNDED, True),
                ("Albaranes", "/albaranes", ft.Icons.LOCAL_SHIPPING_ROUNDED, False),
                ("Compras", "/compras", ft.Icons.SHOPPING_BAG_ROUNDED, False),
                ("Asistente IA", "/asistente", ft.Icons.SMART_TOY_ROUNDED, False),
                ("Historial", "/historial", ft.Icons.HISTORY_ROUNDED, False),
                ("Contactos", "/clientes", ft.Icons.PEOPLE_ALT_ROUNDED, False),
                ("Balance", "/gastos", ft.Icons.ACCOUNT_BALANCE_WALLET_ROUNDED, False),
            ]

            def construir_tarjeta(titulo, r_ruta, icono, destacada):
                bg_normal = "#FFFFFF" if destacada else "#1E293B"
                bg_hover = "#F1F5F9" if destacada else "#2D3748"
                icon_color = "#0284C7" if destacada else "#38BDF8"
                text_color = "#0F172A" if destacada else "#F8FAFC"
                borde_color = "#0284C7" if destacada else "#334155"
                ancho_borde = 2 if destacada else 1

                card_container = ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Icon(icono, size=40, color=icon_color),
                            ft.Text(titulo, size=13, weight=ft.FontWeight.W_600,
                                    color=text_color, text_align=ft.TextAlign.CENTER)
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=8
                    ),
                    alignment=ft.Alignment(0, 0),
                    bgcolor=bg_normal,
                    border=ft.Border.all(ancho_borde, borde_color),
                    border_radius=16,
                    height=120,
                    animate=ft.Animation(180, ft.AnimationCurve.EASE_OUT),
                    ink=True,
                    on_click=lambda e, r=r_ruta: page.go(r)
                )

                def on_hover(e):
                    card_container.bgcolor = bg_hover if e.data == "true" else bg_normal
                    card_container.update()

                card_container.on_hover = on_hover
                return ft.Column(controls=[card_container], col={"xs": 6, "sm": 4, "md": 3})

            columnas_grid = [construir_tarjeta(
                t, r, i, d) for t, r, i, d in tarjetas_menu]

            return ft.View(
                route="/",
                controls=[
                    ft.Container(
                        content=ft.Column(
                            controls=[
                                ft.Container(height=15),
                                ft.Row(
                                    controls=[
                                        ft.Text(
                                            "LZ79", size=28, weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                                        ft.Text(
                                            "Freelance", size=22, weight=ft.FontWeight.W_400, color="#94A3B8")
                                    ],
                                    alignment=ft.MainAxisAlignment.CENTER,
                                    spacing=8
                                ),
                                ft.Container(height=3, width=80, bgcolor=COLOR_ACCENTO,
                                             border_radius=2, margin=ft.Margin(0, 4, 0, 15)),
                                ft.ResponsiveRow(
                                    controls=columnas_grid, spacing=14, run_spacing=14),
                            ],
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            scroll=ft.ScrollMode.AUTO,
                            expand=True
                        ),
                        padding=20,
                        expand=True
                    )
                ],
                vertical_alignment=ft.MainAxisAlignment.START,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                bgcolor=COLOR_FONDO
            )

        elif route == "/asistente":
            lista_mensajes = ft.ListView(
                expand=True, spacing=10, auto_scroll=True)
            txt_pregunta = ft.TextField(
                hint_text="Pregunta sobre stock, IVA, facturas o pulsa Escanear...",
                border_color=COLOR_ACCENTO,
                expand=True
            )

            def agregar_burbuja(autor: str, texto_m: str, es_bot: bool):
                bg_c = "#1E293B" if es_bot else "#0284C7"
                align = ft.CrossAxisAlignment.START if es_bot else ft.CrossAxisAlignment.END
                txt_c = COLOR_TEXTO if es_bot else "#FFFFFF"

                burbuja = ft.Container(
                    content=ft.Column([
                        ft.Text(autor, size=10, weight=ft.FontWeight.BOLD,
                                color=COLOR_ACCENTO if es_bot else "#E0F2FE"),
                        ft.Markdown(texto_m, selectable=True)
                    ], spacing=2),
                    bgcolor=bg_c,
                    padding=10,
                    border_radius=12,
                    width=380
                )
                lista_mensajes.controls.append(
                    ft.Column([burbuja], horizontal_alignment=align))
                page.update()

            agregar_burbuja(
                "Asistente LZ79", "¡Hola! ¿En qué te ayudo hoy? Puedes consultar **balance**, **IVA**, **alertas de stock**, **facturas**, **albaranes**, **compras**, **contactos**, **trimestre**, el **mejor cliente**, o usar el **escáner continuo**.", True)

            def enviar_mensaje_click(e):
                val = txt_pregunta.value.strip()
                if not val:
                    return
                agregar_burbuja("Tú", val, False)
                txt_pregunta.value = ""
                page.update()

                respuesta = procesar_consulta_asistente(val)
                agregar_burbuja("Asistente LZ79", respuesta, True)

            txt_pregunta.on_submit = enviar_mensaje_click

            def escanear_en_asistente(e):
                def al_leer(codigo):
                    concepto, imp = procesar_texto_factura_qr(codigo)
                    txt_resp = f"📷 **Código QR / Barra Detectado:**\n\n`{codigo}`\n\n"
                    if imp > 0:
                        txt_resp += f"• **Importe extraído:** {imp:.2f} €\n• **Concepto:** {concepto}"
                    else:
                        txt_resp += f"• **Contenido:** {concepto}"
                    agregar_burbuja("Escáner", txt_resp, True)

                threading.Thread(target=escanear_qr,
                                  args=(al_leer,), daemon=True).start()

            return ft.View(
                route="/asistente",
                controls=[
                    ft.Container(
                        content=ft.Column([
                            ft.Row([
                                ft.Text("Asistente & Escáner", size=22,
                                        weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                                ft.ElevatedButton(
                                    "📷 Escáner Universal (QR/Barras)", on_click=escanear_en_asistente, bgcolor="#064E3B", color="#4ADE80")
                            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                            ft.Divider(color="#334155"),
                            lista_mensajes,
                            ft.Row([
                                txt_pregunta,
                                ft.IconButton(
                                    icon=ft.Icons.SEND_ROUNDED, icon_color=COLOR_ACCENTO, on_click=enviar_mensaje_click)
                            ]),
                            ft.TextButton("← Volver al Menú", on_click=lambda e: page.go(
                                "/"), width=float("inf"))
                        ], expand=True),
                        padding=15,
                        expand=True
                    )
                ],
                bgcolor=COLOR_FONDO
            )

        elif route == "/historial":
            movs = obtener_todos_movimientos_db()
            filas_historial = []
            for m_id, num, tipo, f_hora, cli, conc, imp in movs:
                es_v = "Facturas" in tipo or "Ventas" in tipo
                col_imp = "#4ADE80" if es_v else "#F87171"
                filas_historial.append(
                    ft.DataRow(cells=[
                        ft.DataCell(
                            ft.Text(num, size=11, weight="bold", color=COLOR_ACCENTO)),
                        ft.DataCell(ft.Text(tipo, size=11, color=COLOR_TEXTO)),
                        ft.DataCell(
                            ft.Text(f_hora[:10], size=11, color="#94A3B8")),
                        ft.DataCell(
                            ft.Text(cli[:15] if cli else "-", size=11, color=COLOR_TEXTO)),
                        ft.DataCell(
                            ft.Text(f"{imp:.2f} €", size=11, weight="bold", color=col_imp))
                    ])
                )

            tabla_historial = ft.DataTable(
                columns=[
                    ft.DataColumn(ft.Text("Nº Doc", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Tipo", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Fecha", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Contacto", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Total", size=11, weight="bold")),
                ],
                rows=filas_historial,
                heading_row_color="#334155",
            )

            lbl_integridad = ft.Text("", size=12)

            def verificar_integridad_click(e):
                integra, mensaje, _num_doc = verificar_cadena_movimientos()
                lbl_integridad.value = ("🔒 " if integra else "🚨 ") + mensaje
                lbl_integridad.color = "#4ADE80" if integra else "#F87171"
                page.update()

            return ft.View(
                route="/historial",
                controls=[
                    ft.Column([
                        ft.Text("Historial de Registros", size=24,
                                weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                        ft.Row([tabla_historial], scroll=ft.ScrollMode.ALWAYS),
                        ft.Container(height=6),
                        ft.ElevatedButton(
                            "🔒 Verificar integridad de la cadena",
                            on_click=verificar_integridad_click,
                            width=float("inf"), bgcolor="#1E293B", color=COLOR_ACCENTO
                        ),
                        lbl_integridad,
                        ft.Container(height=10),
                        ft.TextButton("← Volver al Menú", on_click=lambda e: page.go(
                            "/"), width=float("inf"))
                    ], scroll=ft.ScrollMode.AUTO, expand=True, spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
                ],
                bgcolor=COLOR_FONDO
            )

        elif route == "/almacen" or route == "/almacen/nuevo" or route.startswith("/almacen/editar/"):
            if route == "/almacen/nuevo":
                txt_sku = ft.TextField(
                    label="SKU / Código Producto", border_color=COLOR_ACCENTO)
                txt_desc = ft.TextField(
                    label="Descripción del Producto", border_color=COLOR_ACCENTO)
                txt_cat = ft.TextField(
                    label="Categoría", border_color=COLOR_ACCENTO)
                txt_stock = ft.TextField(
                    label="Stock Actual", border_color=COLOR_ACCENTO)
                txt_min = ft.TextField(
                    label="Stock Mínimo Alerta", border_color=COLOR_ACCENTO)
                txt_costo = ft.TextField(
                    label="Costo Unitario (€)", border_color=COLOR_ACCENTO)
                lbl_msg_prod = ft.Text("", size=13)

                def guardar_prod_click(e):
                    try:
                        sku = txt_sku.value.strip()
                        desc = txt_desc.value.strip()
                        cat = txt_cat.value.strip()
                        stock = int(txt_stock.value.strip())
                        minimo = int(txt_min.value.strip())
                        costo = float(
                            txt_costo.value.replace(",", ".").strip())

                        if sku and desc:
                            if guardar_producto_inventario_db(sku, desc, cat, stock, minimo, costo):
                                lbl_msg_prod.value = "✅ Producto guardado con éxito."
                                lbl_msg_prod.color = "green"
                                txt_sku.value = ""
                                txt_desc.value = ""
                                txt_cat.value = ""
                                txt_stock.value = ""
                                txt_min.value = ""
                                txt_costo.value = ""
                            else:
                                lbl_msg_prod.value = "⚠️ Error al guardar."
                                lbl_msg_prod.color = "red"
                        else:
                            lbl_msg_prod.value = "⚠️ Rellene al menos SKU y Descripción."
                            lbl_msg_prod.color = "orange"
                        page.update()
                    except ValueError:
                        lbl_msg_prod.value = "⚠️ Revise que stock, mínimo y costo sean numéricos."
                        lbl_msg_prod.color = "red"
                        page.update()

                return ft.View(
                    route="/almacen/nuevo",
                    controls=[
                        wrap_responsive(ft.Column([
                            ft.Text("Nuevo Producto", size=22,
                                    weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                            txt_sku, txt_desc, txt_cat, txt_stock, txt_min, txt_costo, lbl_msg_prod,
                            ft.Container(height=10),
                            ft.ElevatedButton(
                                "Guardar Producto", on_click=guardar_prod_click, width=float("inf"), height=45),
                            ft.TextButton("← Volver", on_click=lambda e: page.go(
                                "/almacen"), width=float("inf"))
                        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER))
                    ],
                    bgcolor=COLOR_FONDO
                )

            elif route.startswith("/almacen/editar/"):
                sku_editar = route.split("/")[-1]
                prod = obtener_producto_por_sku(sku_editar)

                if not prod:
                    page.go("/almacen")
                    return ft.View(route="/almacen")

                txt_sku = ft.TextField(
                    label="SKU", value=prod[0], border_color=COLOR_ACCENTO, read_only=True)
                txt_desc = ft.TextField(
                    label="Descripción", value=prod[1], border_color=COLOR_ACCENTO)
                txt_cat = ft.TextField(
                    label="Categoría", value=prod[2], border_color=COLOR_ACCENTO)
                txt_stock = ft.TextField(label="Stock Actual", value=str(
                    prod[3]), border_color=COLOR_ACCENTO)
                txt_min = ft.TextField(label="Stock Mínimo", value=str(
                    prod[4]), border_color=COLOR_ACCENTO)
                txt_costo = ft.TextField(label="Costo Unitario (€)", value=str(
                    prod[5]), border_color=COLOR_ACCENTO)
                lbl_msg_edit = ft.Text("", size=13)

                def actualizar_prod_click(e):
                    try:
                        stock = int(txt_stock.value.strip())
                        minimo = int(txt_min.value.strip())
                        costo = float(
                            txt_costo.value.replace(",", ".").strip())
                        guardar_producto_inventario_db(
                            prod[0], txt_desc.value.strip(), txt_cat.value.strip(), stock, minimo, costo)
                        lbl_msg_edit.value = "✅ Actualizado correctamente."
                        lbl_msg_edit.color = "green"
                        page.update()
                    except ValueError:
                        lbl_msg_edit.value = "⚠️ Valores numéricos inválidos."
                        lbl_msg_edit.color = "red"
                        page.update()

                return ft.View(
                    route=route,
                    controls=[
                        wrap_responsive(ft.Column([
                            ft.Text(
                                f"Editar: {prod[0]}", size=22, weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                            txt_sku, txt_desc, txt_cat, txt_stock, txt_min, txt_costo, lbl_msg_edit,
                            ft.Container(height=10),
                            ft.ElevatedButton(
                                "Guardar Cambios", on_click=actualizar_prod_click, width=float("inf"), height=45),
                            ft.TextButton("← Volver", on_click=lambda e: page.go(
                                "/almacen"), width=float("inf"))
                        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER))
                    ],
                    bgcolor=COLOR_FONDO
                )

            lbl_msg_inv = ft.Text("", size=12)

            def exportar_y_avisar(e):
                ruta = exportar_inventario_excel()
                lbl_msg_inv.value = f"📁 Excel guardado en: {ruta}"
                lbl_msg_inv.color = COLOR_ACCENTO
                page.update()

            def sincronizar_excel_click(e):
                exito, mensaje = importar_inventario_excel()
                lbl_msg_inv.value = mensaje
                lbl_msg_inv.color = "green" if exito else "red"
                page.views.clear()
                page.views.append(crear_vista("/almacen"))
                page.update()

            def vaciar_todo_click(e):
                vaciar_inventario_db()
                lbl_msg_inv.value = "⚠️ Inventario vaciado por completo."
                lbl_msg_inv.color = "orange"
                page.views.clear()
                page.views.append(crear_vista("/almacen"))
                page.update()

            items_inventario = obtener_inventario_db()
            filas_tabla = []

            for sku, desc, cat, stock, min_val, costo in items_inventario:
                estado = "✅ OK" if stock >= min_val else "⚠️ REPOSICIÓN"
                color_estado = "green" if stock >= min_val else "red"
                total_val = stock * costo

                def hacer_edicion(s=sku):
                    page.go(f"/almacen/editar/{s}")

                def hacer_borrado(s=sku):
                    eliminar_producto_inventario_db(s)
                    page.views.clear()
                    page.views.append(crear_vista("/almacen"))
                    page.update()

                filas_tabla.append(
                    ft.DataRow(cells=[
                        ft.DataCell(ft.Text(sku, size=11, color=COLOR_TEXTO)),
                        ft.DataCell(ft.Text(desc, size=11, color=COLOR_TEXTO)),
                        ft.DataCell(
                            ft.Text(str(stock), size=11, color=COLOR_TEXTO)),
                        ft.DataCell(
                            ft.Text(f"{total_val:.2f} €", size=11, color=COLOR_TEXTO)),
                        ft.DataCell(ft.Text(estado, size=11,
                                    color=color_estado, weight="bold")),
                        ft.DataCell(ft.Row([
                            ft.TextButton(
                                "✏️ Editar", on_click=lambda e, s=sku: hacer_edicion(s)),
                            ft.TextButton(
                                "❌ Borrar", on_click=lambda e, s=sku: hacer_borrado(s))
                        ], spacing=0))
                    ])
                )

            tabla_stock = ft.DataTable(
                columns=[
                    ft.DataColumn(ft.Text("SKU", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Producto", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Stock", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Valor", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Estado", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Acción", size=11, weight="bold")),
                ],
                rows=filas_tabla,
                heading_row_color="#334155",
            )

            return ft.View(
                route="/almacen",
                controls=[
                    ft.Column([
                        ft.Text("Inventario", size=24,
                                weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                        lbl_msg_inv,
                        ft.Row([tabla_stock], scroll=ft.ScrollMode.ALWAYS),
                        ft.Container(height=10),
                        ft.ResponsiveRow([
                            ft.Column([ft.ElevatedButton("➕ Añadir", on_click=lambda e: page.go(
                                "/almacen/nuevo"), width=float("inf"), bgcolor="#064E3B", color="#4ADE80")], col={"xs": 6, "sm": 3}),
                            ft.Column([ft.ElevatedButton("📤 Exportar", on_click=exportar_y_avisar, width=float(
                                "inf"), bgcolor="#1E293B", color=COLOR_ACCENTO)], col={"xs": 6, "sm": 3}),
                            ft.Column([ft.ElevatedButton("📥 Sinc", on_click=sincronizar_excel_click, width=float(
                                "inf"), bgcolor="#064E3B", color="#4ADE80")], col={"xs": 6, "sm": 3}),
                            ft.Column([ft.ElevatedButton("🗑️ Vaciar", on_click=vaciar_todo_click, width=float(
                                "inf"), bgcolor="#7F1D1D", color="#F87171")], col={"xs": 6, "sm": 3}),
                        ]),
                        ft.TextButton("← Volver al Menú", on_click=lambda e: page.go(
                            "/"), width=float("inf"))
                    ], scroll=ft.ScrollMode.AUTO, expand=True, spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
                ],
                bgcolor=COLOR_FONDO
            )

        elif route == "/facturas":
            lista_clientes = obtener_contactos_db(es_proveedor=0)
            dd_cliente_factura = ft.Dropdown(
                label="Cliente", border_color=COLOR_ACCENTO,
                options=[ft.dropdown.Option(c[1]) for c in lista_clientes]
            )
            txt_concepto_factura = ft.TextField(
                label="Concepto", border_color=COLOR_ACCENTO)
            txt_importe_base_f = ft.TextField(
                label="Base Imponible (€)", border_color=COLOR_ACCENTO)

            dd_iva_factura = ft.Dropdown(
                label="IVA", value="21", border_color=COLOR_ACCENTO,
                options=[
                    ft.dropdown.Option("21", "21% General"),
                    ft.dropdown.Option("10", "10% Reducido"),
                    ft.dropdown.Option("4", "4% Superreducido"),
                    ft.dropdown.Option("0", "0% Exento / Export.")
                ]
            )

            dd_irpf_factura = ft.Dropdown(
                label="Retención IRPF", value="0", border_color=COLOR_ACCENTO,
                options=[
                    ft.dropdown.Option("0", "0% (Sin retención)"),
                    ft.dropdown.Option("7", "7% (Nuevo autónomo)"),
                    ft.dropdown.Option("15", "15% (Profesional estándar)"),
                    ft.dropdown.Option("19", "19% (Alquileres)")
                ]
            )

            dd_recargo_factura = ft.Dropdown(
                label="Recargo Equivalencia", value="0", border_color=COLOR_ACCENTO,
                options=[
                    ft.dropdown.Option("0", "0% (No aplica)"),
                    ft.dropdown.Option("5.2", "5.2% (IVA 21%)"),
                    ft.dropdown.Option("1.4", "1.4% (IVA 10%)"),
                    ft.dropdown.Option("0.5", "0.5% (IVA 4%)")
                ]
            )

            lbl_desglose_calc = ft.Text(
                "IVA: 0.00 € | IRPF: 0.00 € | RE: 0.00 €", size=12, color=COLOR_ACCENTO)
            lbl_total_calc_f = ft.Text(
                "Total Factura: 0.00 €", size=18, weight=ft.FontWeight.BOLD, color="#4ADE80")
            lbl_msg_factura = ft.Text("", size=13)

            def calcular_totales_factura(e):
                try:
                    base = float(txt_importe_base_f.value.replace(",", "."))
                    tipo_iva = float(dd_iva_factura.value)
                    tipo_irpf = float(dd_irpf_factura.value)
                    tipo_rec = float(dd_recargo_factura.value)

                    c_iva = round(base * (tipo_iva / 100.0), 2)
                    c_irpf = round(base * (tipo_irpf / 100.0), 2)
                    c_rec = round(base * (tipo_rec / 100.0), 2)
                    total = round(base + c_iva + c_rec - c_irpf, 2)

                    lbl_desglose_calc.value = f"IVA: +{c_iva:.2f} €  |  IRPF: -{c_irpf:.2f} €  |  RE: +{c_rec:.2f} €"
                    lbl_total_calc_f.value = f"Total a Cobrar: {total:.2f} €"
                except ValueError:
                    lbl_desglose_calc.value = "IVA: 0.00 € | IRPF: 0.00 € | RE: 0.00 €"
                    lbl_total_calc_f.value = "Total Factura: 0.00 €"
                page.update()

            txt_importe_base_f.on_change = calcular_totales_factura
            dd_iva_factura.on_change = calcular_totales_factura
            dd_irpf_factura.on_change = calcular_totales_factura
            dd_recargo_factura.on_change = calcular_totales_factura

            def escanear_factura_completa(e):
                def al_leer(codigo):
                    concepto, importe = procesar_texto_factura_qr(codigo)
                    txt_concepto_factura.value = f"Factura QR: {concepto}"
                    if importe > 0:
                        txt_importe_base_f.value = str(importe)
                        calcular_totales_factura(None)
                    page.update()
                threading.Thread(target=escanear_qr,
                                  args=(al_leer,), daemon=True).start()

            def guardar_factura_click(e):
                try:
                    base = float(txt_importe_base_f.value.replace(",", "."))
                    tipo_iva = float(dd_iva_factura.value)
                    tipo_irpf = float(dd_irpf_factura.value)
                    tipo_rec = float(dd_recargo_factura.value)

                    c_iva = round(base * (tipo_iva / 100.0), 2)
                    c_irpf = round(base * (tipo_irpf / 100.0), 2)
                    c_rec = round(base * (tipo_rec / 100.0), 2)
                    total = round(base + c_iva + c_rec - c_irpf, 2)

                    cli = dd_cliente_factura.value if dd_cliente_factura.value else "Cliente Genérico"
                    conc = txt_concepto_factura.value.strip(
                    ) if txt_concepto_factura.value else "Factura de Servicios"

                    num_doc, fecha_hora = guardar_movimiento_db(
                        "Facturas", conc, total, cli)
                    generar_html_documento_individual(
                        num_doc, "Factura", conc, base, c_iva, tipo_iva, c_irpf, tipo_irpf, c_rec, total, cli, fecha_hora
                    )

                    lbl_msg_factura.value = f"✅ Factura {num_doc} generada con éxito."
                    lbl_msg_factura.color = "green"
                    txt_importe_base_f.value = ""
                    txt_concepto_factura.value = ""
                    page.update()
                except ValueError:
                    lbl_msg_factura.value = "⚠️ Importe o valores fiscales inválidos."
                    lbl_msg_factura.color = "red"
                    page.update()

            return ft.View(
                route="/facturas",
                controls=[
                    wrap_responsive(ft.Column([
                        ft.Text("Nueva Factura", size=22,
                                weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                        dd_cliente_factura,
                        txt_concepto_factura,
                        txt_importe_base_f,
                        ft.ResponsiveRow([
                            ft.Column([dd_iva_factura], col={
                                      "xs": 12, "sm": 4}),
                            ft.Column([dd_irpf_factura], col={
                                      "xs": 12, "sm": 4}),
                            ft.Column([dd_recargo_factura],
                                      col={"xs": 12, "sm": 4}),
                        ]),
                        lbl_desglose_calc,
                        lbl_total_calc_f,
                        lbl_msg_factura,
                        ft.ElevatedButton("📷 Escanear QR / Código de Barras", on_click=escanear_factura_completa,
                                          width=float("inf"), bgcolor="#064E3B", color="#4ADE80"),
                        ft.ElevatedButton(
                            "Emitir Factura", on_click=guardar_factura_click, width=float("inf"), height=45),
                        ft.TextButton("← Volver", on_click=lambda e: page.go(
                            "/"), width=float("inf")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER))
                ],
                bgcolor=COLOR_FONDO
            )

        elif route == "/albaranes":
            lista_clientes = obtener_contactos_db(es_proveedor=0)
            dd_cliente_alb = ft.Dropdown(
                label="Cliente", border_color=COLOR_ACCENTO,
                options=[ft.dropdown.Option(c[1]) for c in lista_clientes]
            )
            txt_concepto_alb = ft.TextField(
                label="Concepto Albarán", border_color=COLOR_ACCENTO)
            txt_importe_base_a = ft.TextField(
                label="Importe Base (€)", border_color=COLOR_ACCENTO)

            dd_iva_alb = ft.Dropdown(
                label="IVA", value="21", border_color=COLOR_ACCENTO,
                options=[
                    ft.dropdown.Option("21", "21%"),
                    ft.dropdown.Option("10", "10%"),
                    ft.dropdown.Option("4", "4%"),
                    ft.dropdown.Option("0", "0%")
                ]
            )

            lbl_iva_calc_a = ft.Text(
                "IVA: 0.00 €", size=13, color=COLOR_ACCENTO)
            lbl_total_calc_a = ft.Text(
                "Total: 0.00 €", size=18, weight=ft.FontWeight.BOLD, color="#4ADE80")
            lbl_msg_alb = ft.Text("", size=13)

            def calcular_totales_alb(e):
                try:
                    base = float(txt_importe_base_a.value.replace(",", "."))
                    porcentaje = float(dd_iva_alb.value)
                    total = base + (base * (porcentaje / 100.0))
                    lbl_iva_calc_a.value = f"IVA ({porcentaje}%): {(total - base):.2f} €"
                    lbl_total_calc_a.value = f"Total con IVA: {total:.2f} €"
                except ValueError:
                    lbl_iva_calc_a.value = "IVA: 0.00 €"
                    lbl_total_calc_a.value = "Total con IVA: 0.00 €"
                page.update()

            txt_importe_base_a.on_change = calcular_totales_alb
            dd_iva_alb.on_change = calcular_totales_alb

            def escanear_albaran_completo(e):
                def al_leer(codigo):
                    concepto, importe = procesar_texto_factura_qr(codigo)
                    txt_concepto_alb.value = f"Albarán QR: {concepto}"
                    if importe > 0:
                        txt_importe_base_a.value = str(importe)
                        calcular_totales_alb(None)
                    page.update()
                threading.Thread(target=escanear_qr,
                                  args=(al_leer,), daemon=True).start()

            def guardar_albaran_click(e):
                try:
                    base = float(txt_importe_base_a.value.replace(",", "."))
                    porcentaje = float(dd_iva_alb.value)
                    c_iva = round(base * (porcentaje / 100.0), 2)
                    total = base + c_iva
                    cli = dd_cliente_alb.value if dd_cliente_alb.value else "Cliente Genérico"
                    conc = txt_concepto_alb.value if txt_concepto_alb.value else "Albarán"

                    num_doc, fecha_hora = guardar_movimiento_db(
                        "Albaranes", conc, total, cli)
                    generar_html_documento_individual(
                        num_doc, "Albarán", conc, base, c_iva, porcentaje, 0.0, 0.0, 0.0, total, cli, fecha_hora
                    )

                    lbl_msg_alb.value = f"✅ Albarán {num_doc} guardado."
                    lbl_msg_alb.color = "green"
                    txt_importe_base_a.value = ""
                    txt_concepto_alb.value = ""
                    page.update()
                except ValueError:
                    lbl_msg_alb.value = "⚠️ Importe inválido."
                    lbl_msg_alb.color = "red"
                    page.update()

            return ft.View(
                route="/albaranes",
                controls=[
                    wrap_responsive(ft.Column([
                        ft.Text("Nuevo Albarán", size=22,
                                weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                        dd_cliente_alb,
                        txt_concepto_alb,
                        txt_importe_base_a,
                        dd_iva_alb,
                        lbl_iva_calc_a,
                        lbl_total_calc_a,
                        lbl_msg_alb,
                        ft.ElevatedButton("📷 Escanear QR / Código de Barras", on_click=escanear_albaran_completo,
                                          width=float("inf"), bgcolor="#064E3B", color="#4ADE80"),
                        ft.ElevatedButton(
                            "Guardar Albarán", on_click=guardar_albaran_click, width=float("inf"), height=45),
                        ft.TextButton("← Volver", on_click=lambda e: page.go(
                            "/"), width=float("inf")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER))
                ],
                bgcolor=COLOR_FONDO
            )

        elif route == "/compras":
            lista_prov = obtener_contactos_db(es_proveedor=1)
            dd_prov = ft.Dropdown(
                label="Proveedor", border_color=COLOR_ACCENTO,
                options=[ft.dropdown.Option(p[1]) for p in lista_prov]
            )
            txt_concepto_compra = ft.TextField(
                label="Concepto Compra / Gasto", border_color=COLOR_ACCENTO)
            txt_importe_base_c = ft.TextField(
                label="Base Imponible (€)", border_color=COLOR_ACCENTO)

            dd_iva_compra = ft.Dropdown(
                label="IVA Soportado", value="21", border_color=COLOR_ACCENTO,
                options=[
                    ft.dropdown.Option("21", "21% General"),
                    ft.dropdown.Option("10", "10% Reducido"),
                    ft.dropdown.Option("4", "4% Superreducido"),
                    ft.dropdown.Option("0", "0% Exento")
                ]
            )

            dd_irpf_compra = ft.Dropdown(
                label="Retención Proveedor (IRPF)", value="0", border_color=COLOR_ACCENTO,
                options=[
                    ft.dropdown.Option("0", "0% (Sin retención)"),
                    ft.dropdown.Option("15", "15% (Profesional)"),
                    ft.dropdown.Option("19", "19% (Alquileres / Local)")
                ]
            )

            lbl_desglose_compra = ft.Text(
                "IVA: 0.00 € | IRPF: 0.00 €", size=12, color=COLOR_ACCENTO)
            lbl_total_calc_c = ft.Text(
                "Total Gasto: 0.00 €", size=18, weight=ft.FontWeight.BOLD, color="#F87171")
            lbl_compra_status = ft.Text("", size=13, color=COLOR_ACCENTO)

            def calcular_totales_compra(e):
                try:
                    base = float(txt_importe_base_c.value.replace(",", "."))
                    tipo_iva = float(dd_iva_compra.value)
                    tipo_irpf = float(dd_irpf_compra.value)

                    c_iva = round(base * (tipo_iva / 100.0), 2)
                    c_irpf = round(base * (tipo_irpf / 100.0), 2)
                    total = round(base + c_iva - c_irpf, 2)

                    lbl_desglose_compra.value = f"IVA Soportado: +{c_iva:.2f} €  |  Retención IRPF: -{c_irpf:.2f} €"
                    lbl_total_calc_c.value = f"Total a Pagar: {total:.2f} €"
                except ValueError:
                    lbl_desglose_compra.value = "IVA: 0.00 € | IRPF: 0.00 €"
                    lbl_total_calc_c.value = "Total Gasto: 0.00 €"
                page.update()

            txt_importe_base_c.on_change = calcular_totales_compra
            dd_iva_compra.on_change = calcular_totales_compra
            dd_irpf_compra.on_change = calcular_totales_compra

            def escanear_compra_completa(e):
                def al_leer(codigo):
                    concepto, importe = procesar_texto_factura_qr(codigo)
                    txt_concepto_compra.value = f"Compra QR: {concepto}"
                    if importe > 0:
                        txt_importe_base_c.value = str(importe)
                        calcular_totales_compra(None)
                    page.update()
                threading.Thread(target=escanear_qr,
                                  args=(al_leer,), daemon=True).start()

            def guardar_compra_click(e):
                try:
                    base = float(txt_importe_base_c.value.replace(",", "."))
                    tipo_iva = float(dd_iva_compra.value)
                    tipo_irpf = float(dd_irpf_compra.value)

                    c_iva = round(base * (tipo_iva / 100.0), 2)
                    c_irpf = round(base * (tipo_irpf / 100.0), 2)
                    total = round(base + c_iva - c_irpf, 2)

                    prov = dd_prov.value if dd_prov.value else "Proveedor Genérico"
                    conc = txt_concepto_compra.value if txt_concepto_compra.value else "Gasto"

                    num_doc, fecha_hora = guardar_movimiento_db(
                        "Compras / Gastos", conc, total, prov)
                    generar_html_documento_individual(
                        num_doc, "Compra", conc, base, c_iva, tipo_iva, c_irpf, tipo_irpf, 0.0, total, prov, fecha_hora
                    )

                    lbl_compra_status.value = f"✅ Registrado {num_doc}."
                    txt_concepto_compra.value = ""
                    txt_importe_base_c.value = ""
                    page.update()
                except ValueError:
                    lbl_compra_status.value = "⚠️ Importe inválido."
                    page.update()

            return ft.View(
                route="/compras",
                controls=[
                    wrap_responsive(ft.Column([
                        ft.Text("Módulo Compras / Gastos", size=22,
                                weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                        dd_prov,
                        txt_concepto_compra,
                        txt_importe_base_c,
                        ft.ResponsiveRow([
                            ft.Column([dd_iva_compra], col={
                                      "xs": 12, "sm": 6}),
                            ft.Column([dd_irpf_compra], col={
                                      "xs": 12, "sm": 6}),
                        ]),
                        lbl_desglose_compra,
                        lbl_total_calc_c,
                        lbl_compra_status,
                        ft.ElevatedButton("📷 Escanear QR / Código de Barras", on_click=escanear_compra_completa,
                                          width=float("inf"), bgcolor="#064E3B", color="#4ADE80"),
                        ft.ElevatedButton(
                            "Guardar Compra", on_click=guardar_compra_click, width=float("inf"), height=45),
                        ft.TextButton("← Volver", on_click=lambda e: page.go(
                            "/"), width=float("inf")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER))
                ],
                bgcolor=COLOR_FONDO
            )

        elif route == "/clientes":
            in_nombre = ft.TextField(
                label="Nombre / Empresa", border_color=COLOR_ACCENTO)
            in_cif = ft.TextField(
                label="CIF / NIF", border_color=COLOR_ACCENTO)
            in_dir = ft.TextField(
                label="Dirección", border_color=COLOR_ACCENTO)

            rg_tipo_contacto = ft.RadioGroup(content=ft.Row([
                ft.Radio(value="cliente", label="Cliente"),
                ft.Radio(value="proveedor", label="Proveedor")
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=20), value="cliente")

            lbl_cli_msg = ft.Text("", size=13)

            def guardar_contacto_click(e):
                if in_nombre.value and in_cif.value:
                    es_p = 1 if rg_tipo_contacto.value == "proveedor" else 0
                    if guardar_contacto_db(in_nombre.value.strip(), in_cif.value.strip(), in_dir.value.strip(), es_p):
                        lbl_cli_msg.value = "✅ Guardado correctamente."
                        lbl_cli_msg.color = "green"
                        in_nombre.value = ""
                        in_cif.value = ""
                        in_dir.value = ""
                        page.views.clear()
                        page.views.append(crear_vista("/clientes"))
                        page.update()
                    else:
                        lbl_cli_msg.value = "⚠️ Ya existe un contacto con ese nombre."
                        lbl_cli_msg.color = "red"
                else:
                    lbl_cli_msg.value = "⚠️ Rellena Nombre y CIF."
                    lbl_cli_msg.color = "orange"
                page.update()

            contactos_db = obtener_contactos_db()
            filas_contactos = []
            for c_id, nom, cif_val, direc, es_prov in contactos_db:
                tipo_str = "Proveedor" if es_prov == 1 else "Cliente"
                color_tag = "#38BDF8" if es_prov == 1 else "#4ADE80"

                def borrar_contacto(id_c=c_id):
                    eliminar_contacto_db(id_c)
                    page.views.clear()
                    page.views.append(crear_vista("/clientes"))
                    page.update()

                filas_contactos.append(
                    ft.DataRow(cells=[
                        ft.DataCell(ft.Text(nom, size=11, color=COLOR_TEXTO)),
                        ft.DataCell(
                            ft.Text(cif_val, size=11, color=COLOR_TEXTO)),
                        ft.DataCell(ft.Text(tipo_str, size=11,
                                    color=color_tag, weight="bold")),
                        ft.DataCell(ft.TextButton(
                            "❌", on_click=lambda e, id_c=c_id: borrar_contacto(id_c)))
                    ])
                )

            tabla_contactos = ft.DataTable(
                columns=[
                    ft.DataColumn(ft.Text("Nombre", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("CIF", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Tipo", size=11, weight="bold")),
                    ft.DataColumn(ft.Text("Borrar", size=11, weight="bold")),
                ],
                rows=filas_contactos,
                heading_row_color="#334155",
            )

            return ft.View(
                route="/clientes",
                controls=[
                    wrap_responsive(ft.Column([
                        ft.Text("Gestión de Contactos", size=24,
                                weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                        in_nombre, in_cif, in_dir,
                        ft.Text("Tipo de Contacto:", size=13,
                                color=COLOR_ACCENTO, weight=ft.FontWeight.W_600),
                        rg_tipo_contacto, lbl_cli_msg,
                        ft.ElevatedButton(
                            "Guardar Contacto", on_click=guardar_contacto_click, width=float("inf"), height=45),
                        ft.Container(height=15),
                        ft.Text("Directorio Existente", size=16,
                                weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                        ft.Row([tabla_contactos], scroll=ft.ScrollMode.ALWAYS),
                        ft.TextButton("← Volver al Menú", on_click=lambda e: page.go(
                            "/"), width=float("inf"))
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER))
                ],
                bgcolor=COLOR_FONDO
            )

        elif route == "/gastos":
            ing, gas = cargar_totales_db()
            dif = ing - gas
            color_dif = "#4ADE80" if dif >= 0 else "#F87171"
            signo_dif = "+" if dif >= 0 else ""

            return ft.View(
                route="/gastos",
                controls=[
                    wrap_responsive(ft.Column([
                        ft.Text("Balance Financiero", size=26,
                                weight=ft.FontWeight.BOLD, color=COLOR_ACCENTO),
                        ft.Container(height=10),
                        ft.ResponsiveRow([
                            ft.Column([ft.Container(content=ft.Column([ft.Text("INGRESOS", size=10), ft.Text(
                                f"+{ing:,.2f}€", size=14, color="#4ADE80", weight="bold")]), padding=10, bgcolor="#064E3B", border_radius=8)], col={"xs": 12, "sm": 4}),
                            ft.Column([ft.Container(content=ft.Column([ft.Text("GASTOS", size=10), ft.Text(
                                f"-{gas:,.2f}€", size=14, color="#F87171", weight="bold")]), padding=10, bgcolor="#7F1D1D", border_radius=8)], col={"xs": 12, "sm": 4}),
                            ft.Column([ft.Container(content=ft.Column([ft.Text("DIFERENCIA", size=10), ft.Text(
                                f"{signo_dif}{dif:,.2f}€", size=14, color=color_dif, weight="bold")]), padding=10, bgcolor="#1E293B", border_radius=8)], col={"xs": 12, "sm": 4}),
                        ], spacing=10),
                        ft.Container(height=20),
                        ft.TextButton("← Volver al Menú", on_click=lambda e: page.go(
                            "/"), width=float("inf"))
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER))
                ],
                bgcolor=COLOR_FONDO
            )

        return ft.View(route="/", controls=[ft.Text("Página no encontrada", color="white")])

    def route_change(route):
        page.views.clear()
        page.views.append(crear_vista(page.route))
        page.update()

    def view_pop(view):
        if len(page.views) > 1:
            page.views.pop()
            top_view = page.views[-1]
            page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop

    page.views.append(crear_vista("/"))
    page.update()


if __name__ == "__main__":
    ft.app(target=main)
